: have heard of problems with -lc_s on Altos 486
set `echo " $libswanted " | sed "s/ c_s / /"`
libswanted="$*"
